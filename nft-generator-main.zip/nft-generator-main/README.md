# nft-generator
Generator NFT and upload into IPFS server within a few minutes
